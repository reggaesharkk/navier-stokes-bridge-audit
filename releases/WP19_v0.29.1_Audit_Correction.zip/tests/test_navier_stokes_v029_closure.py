#!/usr/bin/env python3
"""
Deterministic Unit & Regression Test Suite for `navier-stokes-bridge-audit` v0.29
(`tests/test_navier_stokes_v029_closure.py`).

Compatible with `python3 -B`, `python3 -O`, and `python3 -OO`.
"""
from __future__ import annotations

import json
import hashlib
import sys
import unittest
from fractions import Fraction
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT / "src"))
sys.path.insert(0, str(REPO_ROOT / "tools"))

import check_ns_lean_axioms  # type: ignore
import navier_stokes_v029_closure_suite as suite  # type: ignore


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


class TestNavierStokesV029Closure(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.summary = suite.run_all()
        cls.m1 = json.loads((suite.RESULTS_V029 / "module1_localized_active_hessian.json").read_text(encoding="utf-8"))
        cls.m2 = json.loads((suite.RESULTS_V029 / "module2_two_endpoint_bridge.json").read_text(encoding="utf-8"))
        cls.m3 = json.loads((suite.RESULTS_V029 / "module3_twoscale_dissipative_duhamel.json").read_text(encoding="utf-8"))
        cls.m4 = json.loads((suite.RESULTS_V029 / "module4_reverse_time_reconciliation.json").read_text(encoding="utf-8"))
        cls.m5 = json.loads((suite.RESULTS_V029 / "artifact_integrity_manifest.json").read_text(encoding="utf-8"))

    def test_01_active_support_and_disjoint_orbit_partition(self) -> None:
        topo = self.m1["active_support_topology"]
        require(topo["modes_in_B11"] == 5575, "B_11 mode count must be 5575")
        require(topo["modes_in_B15"] == 14147, "B_15 mode count must be 14147")
        require(topo["active_objective_modes_S_obj"] == 1159, "Active objective mode count must be 1159")
        require(topo["kernel_modes_in_B15"] == 12988, "Kernel mode count in B_15 must be 12988")
        require(topo["active_resonant_pairs_count"] == 1048, "Active resonant pairs count must be 1048")
        require(topo["resonant_pair_overlap_count"] == 0, "Resonant orbit groups must be pairwise disjoint")
        require(topo["max_abs_cg_rg_exact"] == 99, "max |c_g||r_g| must equal 99")

    def test_02_hessian_reduction_and_localized_taylor_closure(self) -> None:
        hc = self.m1["hessian_operator_constants"]
        require(hc["partition_reduction_factor_exact"] == "504", "Disjoint orbit partition reduction must be 504x")
        require(hc["total_algebraic_reduction_factor_exact"] == "2016", "Total algebraic reduction must be 2016x")
        tc = self.m1["certified_n15_endpoint_ball_taylor_closure"]
        require(tc["RG_local_strictly_below_old_Q_plus_B"] is True, "Localized Taylor remainder at N=15 must beat old Q+B")
        require(Fraction(tc["RG_local_over_old_Q_plus_B_decimal"]) < Fraction(1, 1000), "RG_local / old_Q_plus_B must be < 1e-3")
        require(tc["pairwise_perturbation_strictly_below_P"] is True, "Certified pairwise perturbation at N=15 must be below P")
        require(Fraction(tc["pairwise_perturbation_over_P_decimal"]) < Fraction(2, 5), "Pairwise perturbation / P must be < 0.4")

    def test_03_outward_floor_rounding_fix(self) -> None:
        rnd = self.m1["outward_rounding_audit"]
        require(rnd["pass"] is True, "Outward floor rounding check must pass")
        require(
            rnd["repaired_v029_outward_floor_24_places"] == "-163632635604904.374992408432849939981122",
            "Outward floor at 24 places must end in ...1122, not ...1121",
        )

    def test_04_two_endpoint_cross_cutoff_bridge_n11_to_n18(self) -> None:
        s = self.m2["n11_to_n18_supplied_record_checks"]
        require(s["cutoff_count"] == 8, "Must check all 8 supplied rows N=11..18")
        require(s["certificate_json_count"] == 8, "Must check all 8 individual record JSON files")
        require(s["all_k36_locked_36"] is True, "All 36 K36 signs must be locked across N=11..18")
        require(s["all_supplied_signed_numerator_upper_endpoints_negative"] is True, "All supplied signed-numerator upper endpoints must be negative")
        require(s["summary_rows_match_certificate_json"] is True, "Aggregate rows must match individual certificate JSON files")
        n14_15 = self.m2["n14_to_n15_supplied_record_reconciliation"]
        require(n14_15["supplied_n14_n15_signed_numerator_intervals_separated"] is True, "Supplied N14 and N15 signed-numerator intervals must be separated")
        require(
            Fraction(n14_15["supplied_signed_numerator_15_minus_14_lower_decimal"]) > Fraction(1348000000, 1),
            "Supplied signed-numerator N15 - N14 lower endpoint must exceed +1.348e9",
        )

    def test_05_boundary_annulus_telescoping_and_e219_validator(self) -> None:
        tele = self.m3["boundary_annulus_telescoping"]
        require(tele["harmonic_11_exact"] == "83711/27720", "H_11 must equal 83711/27720")
        require(tele["asymptotic_sum_limit_M12_to_inf_exact"] == "83711/304920", "Asymptotic tail limit must be 83711/304920")
        require(tele["exact_telescoping_identity_verified"] is True, "Telescoping identity must hold")
        require(self.m3["e219_modewise_validator_self_test"]["valid"] is True, "e219 modewise validator self-test must pass")

    def test_06_reverse_time_90digit_replay_and_structured_ab(self) -> None:
        segs = self.m4["three_segment_chain_replay"]
        require(len(segs) == 3, "Must replay all 3 segments 239, 238, 237")
        require(
            segs[-1]["outgoing_L_plus_22_5_verified"].startswith("78324232548.82461963074575049977"),
            "Step 237 outgoing conservative bound must match 90-digit certificate",
        )
        ab = self.m4["step_237_structured_fourier_young_ab"]
        require(ab["passes_materiality_gate"] is True, "Step 237 structured A/B ratio 0.334855 must pass < 0.5 gate")

    def test_07_lean_source_scan_and_unauthenticated_checksum_manifest(self) -> None:
        lean_res = check_ns_lean_axioms.audit_lean_source()
        require(lean_res["status"] == "SOURCE_SCAN_ONLY_NO_LEAN_COMPILER", "Scanner must state it is not a Lean compile")
        require(lean_res["theorem_declaration_count"] == 12, "Must identify 12 theorem declarations by source scan")
        require(self.m5["status"] == "CHECKSUMS_RECORDED_NOT_AUTHENTICATED", "Manifest must not imply authenticated sealing")
        require(self.m5["authenticity"] == "NONE", "Unkeyed hashes cannot authenticate the release")
        require(self.m5["verification_boundary"]["continuum_regularity"] == "OPEN", "Continuum regularity remains open")
        require(self.m5["verification_boundary"]["lean_compiler"] == "NOT_RUN_BY_PYTHON_SUITE", "Python suite must not claim to compile Lean")
        require("deterministic_witness_seal_hmac_sha256" not in self.m5, "Manifest must not claim a public-constant HMAC seal")
        for rel, expected in self.m5["artifact_hashes"].items():
            actual = hashlib.sha256((suite.REPO_ROOT / rel).read_bytes()).hexdigest()
            require(actual == expected, f"Artifact checksum mismatch: {rel}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
