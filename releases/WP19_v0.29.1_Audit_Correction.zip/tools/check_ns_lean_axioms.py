#!/usr/bin/env python3
"""
CI & Local Verification Gate for `lean/NavierStokesWP19BridgeCert.lean` (`tools/check_ns_lean_axioms.py`).
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import List

REPO_ROOT = Path(__file__).resolve().parent.parent
LEAN_FILE = REPO_ROOT / "lean" / "NavierStokesWP19BridgeCert.lean"

EXPECTED_THEOREMS: List[str] = [
    "boundary_annulus_numerator_identity",
    "boundary_annulus_two_step_telescope",
    "projection_ignores_second_coordinate_by_definition",
    "scalar_inequality_99_le_49896",
    "algebraic_pair_bound_from_nonnegative_square",
    "conditional_margin_implies_strict_bound",
    "interval_subtraction_bounds",
    "conditional_upper_bound_negativity",
    "two_step_recurrence_monotonicity",
    "linear_damping_from_mode_lower_bound",
    "transitive_decimal_interval_containment",
    "conditional_arithmetic_facts_conjunction",
]


def strip_lean_comments(text: str) -> str:
    text = re.sub(r"/-.*?-/", " ", text, flags=re.DOTALL)
    text = re.sub(r"--[^\n]*", " ", text)
    return text


def audit_lean_source(lean_path: Path = LEAN_FILE) -> dict:
    if not lean_path.exists():
        raise AssertionError(f"Missing Lean module: {lean_path}")
    raw = lean_path.read_text(encoding="utf-8")
    clean = strip_lean_comments(raw)
    for forbidden in ("sorry", "sorryAx", "axiom", "nlinarith"):
        if re.search(rf"\b{forbidden}\b", clean):
            raise AssertionError(f"Forbidden token '{forbidden}' found in {lean_path.name}")
    declared = re.findall(r"\btheorem\s+([A-Za-z0-9_']+)", clean)
    printed = [m.split(".")[-1] for m in re.findall(r"#print\s+axioms\s+([A-Za-z0-9_.']+)", clean)]
    if declared != EXPECTED_THEOREMS:
        raise AssertionError(f"Declared theorems mismatch: got {declared}, expected {EXPECTED_THEOREMS}")
    if printed != EXPECTED_THEOREMS:
        raise AssertionError(f"#print axioms mismatch: got {printed}, expected {EXPECTED_THEOREMS}")
    return {
        "module": str(lean_path.relative_to(REPO_ROOT)),
        "status": "SOURCE_SCAN_ONLY_NO_LEAN_COMPILER",
        "theorem_declaration_count": len(declared),
        "compiled": False,
        "note": "This checks source text and declaration names only. Use Lake/Lean CI to typecheck the module and evaluate #print axioms.",
        "theorems": declared,
        "forbidden_tokens_checked": ["sorry", "sorryAx", "axiom", "nlinarith"],
    }


def main() -> int:
    report = audit_lean_source(LEAN_FILE)
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
