import Mathlib.Tactic.Linarith
import Mathlib.Data.Real.Basic
import Mathlib.Algebra.Order.Ring.Defs

/-!
# Conditional Arithmetic Lemmas Used in the WP19 Audit

Author: Prince Upadhyay (ORCID: 0009-0002-1170-4487)
Version: 0.29.1 (Audit Correction)
Rights: All rights reserved. No reuse license is granted by this notice.

This file contains twelve elementary theorems about identities, inequalities, interval subtraction,
and a projection defined in this file. The results are conditional on their hypotheses. They do not
recompute or validate finite-cutoff certificate data, reproduce the upstream Arb run, establish the
Navier-Stokes estimates described in accompanying research files, or prove continuum regularity.
The Python source scanner is not a compiler; Lake CI builds this module and can run an axiom audit.
-/

namespace NavierStokesWP19Bridge

/-- The scalar identity `M - (M - 11) = 11`. -/
theorem boundary_annulus_numerator_identity (M : ℝ) :
    M - (M - 11) = 11 := by
  linarith

/-- Two successive subtraction differences telescope. -/
theorem boundary_annulus_two_step_telescope (a0 a1 a2 : ℝ) :
    (a0 - a1) + (a1 - a2) = a0 - a2 := by
  linarith

def projectActiveSupport (e_low _e_ker : ℝ) : ℝ := e_low

/-- This projection ignores its second coordinate by definition. It says nothing about
    whether an external research objective has this support property. -/
theorem projection_ignores_second_coordinate_by_definition
    (Q_active : ℝ → ℝ) (e_low e_ker : ℝ) :
    Q_active (projectActiveSupport e_low e_ker) = Q_active (projectActiveSupport e_low 0) := by
  rfl

/-- Elementary scalar comparison for nonnegative `R_sq`; no mode partition is encoded here. -/
theorem scalar_inequality_99_le_49896
    (R_sq : ℝ) (hR : 0 ≤ R_sq) :
    99 * R_sq ≤ 49896 * R_sq ∧
    (0 < R_sq → 99 * R_sq < 49896 * R_sq) := by
  constructor
  · linarith
  · intro h_pos
    linarith

/-- Algebraic consequence of a nonnegative squared-difference expression. -/
theorem algebraic_pair_bound_from_nonnegative_square
    (aP_sq aQ_sq aP_mul_aQ sq_diff : ℝ)
    (h_id : sq_diff = aP_sq - 2 * aP_mul_aQ + aQ_sq)
    (h_sq_nonneg : 0 ≤ sq_diff) :
    2 * aP_mul_aQ ≤ aP_sq + aQ_sq := by
  linarith

/-- If the supplied margin hypothesis places `delta` strictly below `P`, the strict inequality
    follows. This does not verify that an external certificate satisfies the hypotheses. -/
theorem conditional_margin_implies_strict_bound
    (delta P margin : ℝ)
    (h_delta : 0 ≤ delta)
    (h_margin : 0 < margin)
    (h_le : delta + margin ≤ P) :
    delta < P ∧ 0 < P - delta := by
  constructor
  · linarith
  · linarith

/-- Interval subtraction bounds for values assumed to lie in the given intervals. -/
theorem interval_subtraction_bounds
    (x Lx Ux y Ly Uy : ℝ)
    (hx_lo : Lx ≤ x) (hx_hi : x ≤ Ux)
    (hy_lo : Ly ≤ y) (hy_hi : y ≤ Uy) :
    Ly - Ux ≤ y - x ∧
    y - x ≤ Uy - Lx ∧
    (Ux < Ly → 0 < y - x) := by
  refine ⟨by linarith, by linarith, ?_⟩
  intro h_sep
  linarith

/-- Transitivity of supplied upper-bound hypotheses; no certificate data is inspected. -/
theorem conditional_upper_bound_negativity
    (x nominal error certified_upper : ℝ)
    (h_encl : x ≤ nominal + error)
    (h_cert : nominal + error ≤ certified_upper)
    (h_neg : certified_upper < 0) :
    x ≤ certified_upper ∧ x < 0 := by
  constructor
  · linarith
  · linarith

/-- Monotonicity of this scalar two-step recurrence under the stated hypotheses. -/
theorem two_step_recurrence_monotonicity
    (alpha G e0 d1 d2 : ℝ)
    (h_alpha : 0 ≤ alpha) (h_le : alpha ≤ G)
    (he0 : 0 ≤ e0) (hd1 : 0 ≤ d1) (hd2 : 0 ≤ d2) :
    alpha * (alpha * e0 + d1) + d2 ≤ G * (G * e0 + d1) + d2 ∧
    (alpha < G → 0 < d1 → alpha * (alpha * e0 + d1) + d2 < G * (G * e0 + d1) + d2) := by
  have h_G : 0 ≤ G := by linarith
  have h_diff : 0 ≤ G - alpha := by linarith
  have h_ae0_le_Ge0 : alpha * e0 ≤ G * e0 := by
    have h1 : 0 ≤ (G - alpha) * e0 := mul_nonneg h_diff he0
    linarith
  have h_ae0_nonneg : 0 ≤ alpha * e0 := mul_nonneg h_alpha he0
  have h_inner_nonneg : 0 ≤ alpha * e0 + d1 := by linarith
  have h_step1 : alpha * (alpha * e0 + d1) ≤ G * (alpha * e0 + d1) := by
    have h3 : 0 ≤ (G - alpha) * (alpha * e0 + d1) := mul_nonneg h_diff h_inner_nonneg
    linarith
  have h_step2 : G * (alpha * e0 + d1) ≤ G * (G * e0 + d1) := by
    have h_inner_diff : 0 ≤ (G * e0 + d1) - (alpha * e0 + d1) := by linarith
    have h4 : 0 ≤ G * ((G * e0 + d1) - (alpha * e0 + d1)) := mul_nonneg h_G h_inner_diff
    linarith
  constructor
  · linarith
  · intro h_strict hd1_pos
    have h_strict_diff : 0 < G - alpha := by linarith
    have h_inner_pos : 0 < alpha * e0 + d1 := by linarith
    have h_step1_strict : 0 < (G - alpha) * (alpha * e0 + d1) := mul_pos h_strict_diff h_inner_pos
    linarith

/-- Scalar lower bound from the supplied hypothesis `144 ≤ k_sq`; no Fourier shell is encoded. -/
theorem linear_damping_from_mode_lower_bound
    (k_sq : ℝ) (hk : 144 ≤ k_sq) :
    (144 : ℝ) / 10 ≤ (1 / 10) * k_sq := by
  linarith

/-- Transitive containment of a value inside a rounded interval, given four inequalities. -/
theorem transitive_decimal_interval_containment
    (L x_lo x x_hi U : ℝ)
    (h_floor : L ≤ x_lo)
    (h_lo : x_lo ≤ x)
    (h_hi : x ≤ x_hi)
    (h_ceil : x_hi ≤ U) :
    L ≤ x ∧ x ≤ U := by
  constructor
  · linarith
  · linarith

/-- Conjunction of elementary conditional arithmetic facts. Its hypotheses are not derived here. -/
theorem conditional_arithmetic_facts_conjunction
    (R_sq x nominal error certified_upper x0 L0 U0 x1 L1 U1 L x_lo x_hi U : ℝ)
    (hR : 0 ≤ R_sq)
    (h_encl : x ≤ nominal + error)
    (h_cert : nominal + error ≤ certified_upper)
    (h_neg : certified_upper < 0)
    (h0_lo : L0 ≤ x0) (h0_hi : x0 ≤ U0)
    (h1_lo : L1 ≤ x1) (h1_hi : x1 ≤ U1)
    (h_floor : L ≤ x_lo) (h_lo : x_lo ≤ x) (h_hi : x ≤ x_hi) (h_ceil : x_hi ≤ U) :
    (99 * R_sq ≤ 49896 * R_sq) ∧
    (x < 0) ∧
    (L1 - U0 ≤ x1 - x0 ∧ x1 - x0 ≤ U1 - L0) ∧
    (L ≤ x ∧ x ≤ U) := by
  have h_part := (scalar_inequality_99_le_49896 R_sq hR).1
  have h_sign := (conditional_upper_bound_negativity x nominal error certified_upper h_encl h_cert h_neg).2
  have h_inc := interval_subtraction_bounds x0 L0 U0 x1 L1 U1 h0_lo h0_hi h1_lo h1_hi
  have h_out := transitive_decimal_interval_containment L x_lo x x_hi U h_floor h_lo h_hi h_ceil
  exact ⟨h_part, h_sign, ⟨h_inc.1, h_inc.2.1⟩, h_out⟩

#print axioms boundary_annulus_numerator_identity
#print axioms boundary_annulus_two_step_telescope
#print axioms projection_ignores_second_coordinate_by_definition
#print axioms scalar_inequality_99_le_49896
#print axioms algebraic_pair_bound_from_nonnegative_square
#print axioms conditional_margin_implies_strict_bound
#print axioms interval_subtraction_bounds
#print axioms conditional_upper_bound_negativity
#print axioms two_step_recurrence_monotonicity
#print axioms linear_damping_from_mode_lower_bound
#print axioms transitive_decimal_interval_containment
#print axioms conditional_arithmetic_facts_conjunction

end NavierStokesWP19Bridge
