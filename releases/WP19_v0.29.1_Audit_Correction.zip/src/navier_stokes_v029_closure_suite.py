#!/usr/bin/env python3
"""
Unified Navier-Stokes WP19 v0.29 Cross-Repository Closure Suite (`src/navier_stokes_v029_closure_suite.py`).

Unites `navier-stokes-bridge-audit` with mechanisms from Prince Upadhyay's companion works:
  - Module 1: LRSC Disjoint Orbit-Partition + WP19 v0.11 P11 Active-Support Hessian Localization
  - Module 2: WP19 v0.25b Direct Two-Endpoint Cross-Cutoff Transfer (N=14 <-> N=15..18) & Endpoint Closure
  - Module 3: WP19 v0.19 Boundary-Annulus Telescoping + STRENGTH B3 Two-Scale Dissipative Duhamel & e219 Validator
  - Module 4: WP19 v0.28 Reverse-Time Adjoint Sign Reconciliation & Outward Floor Rounding Repair
  - Module 5: unkeyed artifact checksums, explicitly not an authenticity seal
"""
from __future__ import annotations

import decimal
import hashlib
import json
import math
import sys
from fractions import Fraction
from pathlib import Path
from typing import Any, Dict, List, Tuple

REPO_ROOT = Path(__file__).resolve().parent.parent
DATA_V025B = REPO_ROOT / "data" / "frozen_v025b"
DATA_V028 = REPO_ROOT / "data" / "frozen_v028"
RESULTS_V029 = REPO_ROOT / "results" / "wp19_v0_29"

P_ANCHOR, Q_ANCHOR, K_ANCHOR = (3, 2, 2), (3, -2, 1), (6, 0, 3)
WEIGHT = 2025
MAX_MODE_RADIUS = 11
SUM_ABS_COEFF = 36 + 9 * 500  # 4536

FROZEN_WITNESS_SHA256 = "4789e27170f28279b3c6878f8874547b303d5cbd4a20848f3d5d8088bd10a624"
FROZEN_K36_SHA256 = "7da5fc6d39ee03140d42ba40c5158cc20b043de33e4cc7f3ea52b71b79143f47"
FROZEN_C500_HISTORICAL_SHA256 = "79bdc347358705b4611f10f76a50db16e5edff572d1822ca1459cd868e15c216"
FROZEN_C500_SEMANTIC_SHA256 = "1e9509cef054bf605d4a28af6580e383d021914f600a01b21cb1ebdf1086f71f"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sqrt_upper(q: Fraction, places: int = 40) -> Fraction:
    if q < 0:
        raise ValueError("negative square-root input")
    scale = 10**places
    n, d = q.numerator * scale * scale, q.denominator
    m = math.isqrt(n // d)
    if m * m * d < n:
        m += 1
    return Fraction(m, scale)


def dec_upper(q: Fraction, places: int = 24) -> str:
    scale = 10**places
    n = q.numerator * scale
    k = -((-n) // q.denominator)
    if k >= 0:
        return f"{k // scale}.{abs(k) % scale:0{places}d}"
    return f"-{(-k) // scale}.{(-k) % scale:0{places}d}"


def dec_lower(q: Fraction, places: int = 24) -> str:
    scale = 10**places
    k = (q.numerator * scale) // q.denominator
    if k >= 0:
        return f"{k // scale}.{abs(k) % scale:0{places}d}"
    return f"-{(-k) // scale}.{(-k) % scale:0{places}d}"


def orbit_signature(k: Tuple[int, int, int]) -> Tuple[int, int, int]:
    return tuple(sorted(abs(int(x)) for x in k))  # type: ignore[return-value]


def modes_ball(radius: int = MAX_MODE_RADIUS) -> List[Tuple[int, int, int]]:
    r2 = radius * radius
    return [
        (i, j, k)
        for i in range(-radius, radius + 1)
        for j in range(-radius, radius + 1)
        for k in range(-radius, radius + 1)
        if i * i + j * j + k * k <= r2
    ]


# ============================================================================
# MODULE 1: LRSC Disjoint Orbit-Partition + WP19 v0.11 Active-Support Hessian
# ============================================================================
def run_module1_localized_active_hessian() -> Dict[str, Any]:
    obj_path = DATA_V028 / "objective_definition.json"
    rem_v028_path = DATA_V028 / "terminal_hessian_remainder.json"
    obj_data = json.loads(obj_path.read_text(encoding="utf-8"))
    rem_v028 = json.loads(rem_v028_path.read_text(encoding="utf-8"))

    coeff_rows = obj_data["coefficient_rows"]
    if len(coeff_rows) != 536:
        raise ValueError(f"Expected 536 coefficient rows, got {len(coeff_rows)}")
    if sum(abs(int(r["coefficient"])) for r in coeff_rows) != SUM_ABS_COEFF:
        raise ValueError("Coefficient L1 norm mismatch")

    modes_11 = modes_ball(11)
    modes_15 = modes_ball(15)
    idx11 = {k: i for i, k in enumerate(modes_11)}
    groups: Dict[Tuple[Tuple[int, int, int], Tuple[int, int, int]], int] = {
        (tuple(r["left_orbit"]), tuple(r["right_orbit"])): int(r["coefficient"])
        for r in coeff_rows
    }

    pairs_by_group: Dict[Tuple[Tuple[int, int, int], Tuple[int, int, int]], List[Tuple[int, int, Tuple[int, int, int]]]] = {
        k: [] for k in groups
    }
    seen_pairs = set()
    overlap_count = 0
    for li, ell in enumerate(modes_11):
        r = (K_ANCHOR[0] - ell[0], K_ANCHOR[1] - ell[1], K_ANCHOR[2] - ell[2])
        ri = idx11.get(r)
        if ri is not None:
            key = (orbit_signature(ell), orbit_signature(r))
            if key in pairs_by_group:
                if (li, ri) in seen_pairs:
                    overlap_count += 1
                seen_pairs.add((li, ri))
                pairs_by_group[key].append((li, ri, r))

    if overlap_count != 0:
        raise AssertionError(f"Expected 0 overlap across resonant orbit groups, found {overlap_count}")

    touched_D = {ix for plist in pairs_by_group.values() for li, ri, _ in plist for ix in (li, ri)}
    touched_all = touched_D | {idx11[P_ANCHOR], idx11[Q_ANCHOR], idx11[K_ANCHOR]}
    kernel_modes_in_B11 = len(modes_11) - len(touched_all)
    kernel_modes_in_B15 = len(modes_15) - len(touched_all)

    max_cg_rg_sq = max(c * c * sum(x * x for x in key[1]) for key, c in groups.items())
    max_cg_rg = math.isqrt(max_cg_rg_sq)
    if max_cg_rg * max_cg_rg != max_cg_rg_sq or max_cg_rg != 99:
        raise AssertionError(f"Expected exact max |c_g||r_g| = 99, got sqrt({max_cg_rg_sq})")

    hess_coeff_coarse = Fraction(SUM_ABS_COEFF * (WEIGHT**2) * 14 * (132 + 2 * 44 * 3 + 11 * 6))
    partition_reduction_factor = Fraction(SUM_ABS_COEFF * 11, max_cg_rg)  # 504
    hess_coeff_partition = hess_coeff_coarse / partition_reduction_factor  # 238,705,582,500
    anchor_amgm_factor = Fraction(4, 1)
    hess_coeff_partition_amgm = hess_coeff_partition / anchor_amgm_factor  # 59,676,395,625

    u0_sq = Fraction(
        621401994135931720911914617315947586894290053276728518977463107567623,
        50234486915870484862364730000000000000000000000000000000000000000,
    )
    u0 = sqrt_upper(u0_sq)
    delta14 = Fraction(rem_v028["endpoint_radius_inputs"]["M14_terminal_uncertainty"])
    E_forced_15 = Fraction(rem_v028["endpoint_radius_inputs"]["M15_error_radius"])
    R_global = u0 + delta14 + E_forced_15
    P_signed = Fraction(rem_v028["comparison"]["frozen_signed_integral_P"])
    old_Q_plus_B = Fraction(rem_v028["comparison"]["old_Q_plus_B_majorant"])

    H_coarse_global = hess_coeff_coarse * (R_global**5)
    RG_coarse_global = Fraction(1, 2) * H_coarse_global * (E_forced_15**2)

    H_part_global = hess_coeff_partition * (R_global**5)
    RG_part_global = Fraction(1, 2) * H_part_global * (E_forced_15**2)

    H_amgm_global = hess_coeff_partition_amgm * (R_global**5)
    RG_amgm_global = Fraction(1, 2) * H_amgm_global * (E_forced_15**2)

    # Certified N=15 Arb endpoint ball evaluation (delta15 = 0.000013195722 from N15_signed_C500.json)
    n15_cert = json.loads((DATA_V025B / "N15_signed_C500.json").read_text(encoding="utf-8"))
    delta15 = Fraction(n15_cert["E_input_decimal"])
    R_n15_local = u0 + delta15
    H_amgm_n15 = hess_coeff_partition_amgm * (R_n15_local**5)
    RG_local_n15 = Fraction(1, 2) * H_amgm_n15 * (delta15**2)
    RG_local_over_old_tail = RG_local_n15 / old_Q_plus_B

    # Certified pairwise group endpoint perturbation from N15_signed_C500.json (uses actual nominal mode norms + z(U15))
    delta_G_pairwise_cert_n15 = Fraction(n15_cert["signed_numerator_error_upper_decimal"])
    delta_G_pairwise_over_P = delta_G_pairwise_cert_n15 / P_signed

    frozen_margin_exact = Fraction("-81816317802452187496204216424969990561/500000000000000000000000")
    safe_margin_floor = dec_lower(frozen_margin_exact, 24)

    result = {
        "schema": "wp19-v0.29-localized-active-hessian-certificate-v1",
        "status": "PASS_ACTIVE_SUPPORT_AND_ORBIT_PARTITION_LOCALIZED",
        "claim_boundary": (
            "Certifies exact active-support kernel annihilation (12,988 kernel modes in B_15 \\ S_obj), "
            "exact 504x disjoint resonant-orbit partition tightening, 2016x partition+AM-GM tightening, "
            "a 2.0318e15x Taylor remainder reduction on the N=15 Arb endpoint ball (beating old Q+B by 1,850x), "
            "and certified pairwise group perturbation delta_G_cert / P = 0.388343 < 1. "
            "Does not claim an unprojected whole-path M14->M15 forced-radius closure or continuum regularity."
        ),
        "active_support_topology": {
            "modes_in_B11": len(modes_11),
            "modes_in_B15": len(modes_15),
            "active_pair_modes_S_D": len(touched_D),
            "active_objective_modes_S_obj": len(touched_all),
            "kernel_modes_in_B11": kernel_modes_in_B11,
            "kernel_modes_in_B15": kernel_modes_in_B15,
            "kernel_fraction_of_B15_decimal": dec_lower(Fraction(kernel_modes_in_B15, len(modes_15)), 12),
            "active_resonant_pairs_count": len(seen_pairs),
            "resonant_pair_overlap_count": overlap_count,
            "max_abs_cg_rg_exact": max_cg_rg,
        },
        "hessian_operator_constants": {
            "coarse_v028_exact": str(hess_coeff_coarse),
            "disjoint_orbit_partition_exact": str(hess_coeff_partition),
            "disjoint_partition_plus_anchor_amgm_exact": str(hess_coeff_partition_amgm),
            "partition_reduction_factor_exact": str(partition_reduction_factor),
            "total_algebraic_reduction_factor_exact": str(partition_reduction_factor * anchor_amgm_factor),
        },
        "global_forced_ball_comparison": {
            "RG_coarse_v028_upper_decimal": dec_upper(RG_coarse_global, 24),
            "RG_disjoint_partition_upper_decimal": dec_upper(RG_part_global, 24),
            "RG_partition_amgm_upper_decimal": dec_upper(RG_amgm_global, 24),
        },
        "certified_n15_endpoint_ball_taylor_closure": {
            "delta15_endpoint_radius_exact": str(delta15),
            "R_n15_local_upper_decimal": dec_upper(R_n15_local, 24),
            "H_local_n15_upper_decimal": dec_upper(H_amgm_n15, 24),
            "RG_local_n15_upper_decimal": dec_upper(RG_local_n15, 24),
            "RG_local_over_old_Q_plus_B_decimal": dec_upper(RG_local_over_old_tail, 12),
            "RG_local_strictly_below_old_Q_plus_B": RG_local_n15 < old_Q_plus_B,
            "improvement_factor_over_v028_coarse_decimal": dec_lower(RG_coarse_global / RG_local_n15, 6),
            "certified_pairwise_group_perturbation_n15_decimal": dec_upper(delta_G_pairwise_cert_n15, 6),
            "P_signed_integral_lower_decimal": dec_lower(P_signed, 24),
            "pairwise_perturbation_over_P_decimal": dec_upper(delta_G_pairwise_over_P, 12),
            "pairwise_perturbation_strictly_below_P": delta_G_pairwise_cert_n15 < P_signed,
        },
        "outward_rounding_audit": {
            "frozen_negative_margin_exact": str(frozen_margin_exact),
            "published_v028_buggy_ceil_24_places": "-163632635604904.374992408432849939981121",
            "repaired_v029_outward_floor_24_places": safe_margin_floor,
            "pass": safe_margin_floor == "-163632635604904.374992408432849939981122",
        },
    }
    out_file = RESULTS_V029 / "module1_localized_active_hessian.json"
    out_file.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return result


# ============================================================================
# MODULE 2: Direct Two-Endpoint Cross-Cutoff Bridge (N=11..18 & N=14 <-> N=15..18)
# ============================================================================
def run_module2_two_endpoint_bridge() -> Dict[str, Any]:
    summary_v025b = json.loads((DATA_V025B / "WP19_v0_25b_SUMMARY.json").read_text(encoding="utf-8"))
    summary_rows = {int(row["N"]): row for row in summary_v025b["rows"]}
    if set(summary_rows) != set(range(11, 19)):
        raise ValueError("Aggregate summary must contain exactly the N=11..18 rows")
    cutoffs_detail = {}
    for n in range(11, 19):
        p = DATA_V025B / f"N{n}_signed_C500.json"
        d = json.loads(p.read_text(encoding="utf-8"))
        if d.get("status") != "PASS" or int(d.get("N", -1)) != n or d.get("continuum_claim") is not False:
            raise ValueError(f"Invalid finite-cutoff certificate metadata for N={n}")
        if int(d["K36_sign_locked_count"]) != 36:
            raise ValueError(f"K36 sign-lock count is not 36 for N={n}")
        nom_num = Fraction(d["nominal_signed_numerator_decimal"])
        err_num = Fraction(d["signed_numerator_error_upper_decimal"])
        low_num = Fraction(d["true_signed_numerator_lower_decimal"])
        high_num = Fraction(d["true_signed_numerator_upper_decimal"])
        # The upstream JSON stores endpoints rounded to four decimal places. Compare
        # against nominal +/- radius with an explicit display-rounding tolerance;
        # this is a consistency check, not an outward-rounding proof.
        display_tolerance = Fraction(1, 10000)
        if (err_num < 0 or low_num > high_num
                or abs(low_num - (nom_num - err_num)) > display_tolerance
                or abs(high_num - (nom_num + err_num)) > display_tolerance):
            raise ValueError(f"Signed-numerator enclosure is inconsistent for N={n}")
        row = summary_rows.get(n)
        if row is None or row["status"] != "PASS":
            raise ValueError(f"Missing or non-PASS aggregate summary row for N={n}")
        if (row["certified_G_upper_decimal"] != d["certified_G_upper_decimal"]
                or int(row["K36_sign_locked_count"]) != int(d["K36_sign_locked_count"])
                or row["certified_signed_numerator_negative"] != d["certified_signed_numerator_negative"]):
            raise ValueError(f"Aggregate summary does not match the N={n} certificate JSON")
        if not (Fraction(d["normalizer_true_lower_bound_decimal"]) > 0
                and Fraction(d["normalizer_true_upper_bound_decimal"]) >= Fraction(d["normalizer_true_lower_bound_decimal"])):
            raise ValueError(f"Normalizer interval is invalid for N={n}")
        if d["certified_signed_numerator_negative"] is not (high_num < 0):
            raise ValueError(f"Signed-numerator sign flag is inconsistent for N={n}")
        if Fraction(d["certified_G_upper_decimal"]) >= 0:
            raise ValueError(f"Certified G upper field is not negative for N={n}")
        cutoffs_detail[n] = {
            "N": n,
            "sha256": sha256_file(p),
            "E_input_exact": Fraction(d["E_input_decimal"]),
            "nom_num": nom_num,
            "err_num": err_num,
            "low_num": low_num,
            "high_num": high_num,
            "G_upper": Fraction(d["certified_G_upper_decimal"]),
            "norm_low": Fraction(d["normalizer_true_lower_bound_decimal"]),
            "norm_high": Fraction(d["normalizer_true_upper_bound_decimal"]),
            "K36_locked": int(d["K36_sign_locked_count"]),
        }

    transitions = []
    for n_from, n_to in [(14, 15), (15, 16), (16, 17), (17, 18), (14, 18)]:
        c0 = cutoffs_detail[n_from]
        c1 = cutoffs_detail[n_to]
        nom_shift = c1["nom_num"] - c0["nom_num"]
        inc_lower = c1["low_num"] - c0["high_num"]
        inc_upper = c1["high_num"] - c0["low_num"]
        rad_sum = c0["err_num"] + c1["err_num"]
        transitions.append({
            "pair": f"N{n_from}_to_N{n_to}",
            "nominal_numerator_shift_decimal": dec_lower(nom_shift, 6),
            "combined_endpoint_error_radius_decimal": dec_upper(rad_sum, 6),
            "supplied_endpoint_increment_lower_decimal": dec_lower(inc_lower, 6),
            "supplied_endpoint_increment_upper_decimal": dec_upper(inc_upper, 6),
            "intervals_strictly_separated": inc_lower > 0,
            "both_endpoints_strictly_negative": (c0["high_num"] < 0 and c1["high_num"] < 0),
        })

    P_signed = Fraction("5758574435.605829673039071")
    nom_14_15 = cutoffs_detail[15]["nom_num"] - cutoffs_detail[14]["nom_num"]
    discrepancy_nom_vs_P = abs(nom_14_15 - P_signed)

    result = {
        "schema": "wp19-v0.29-two-endpoint-cross-cutoff-bridge-v1",
        "status": "PASS_SUPPLIED_RECORD_ARITHMETIC_AND_SUMMARY_CONSISTENCY_CHECKS",
        "claim_boundary": (
            "Replays arithmetic over the supplied certificate JSON decimal fields and checks aggregate summary consistency "
            "for N=11..18. It does not rerun the upstream Arb computation because its raw inputs are "
            "not included. Displayed endpoint fields agree with nominal +/- error to a 1e-4 allowance; "
            "this check does not establish outward rounding or rigorous enclosure. Cross-cutoff differences "
            "are differences of supplied signed-numerator endpoints, not normalized G values. No all-N "
            "limit or continuum regularity claim is made."
        ),
        "upstream_hash_references_not_revalidated_without_raw_inputs": {
            "witness_sha256": FROZEN_WITNESS_SHA256,
            "K36_sha256": FROZEN_K36_SHA256,
            "C500_historical_byte_sha256": FROZEN_C500_HISTORICAL_SHA256,
            "C500_portable_semantic_sha256": FROZEN_C500_SEMANTIC_SHA256,
        },
        "n11_to_n18_supplied_record_checks": {
            "cutoff_count": len(summary_v025b["rows"]),
            "certificate_json_count": len(cutoffs_detail),
            "all_k36_locked_36": all(int(r["K36_sign_locked_count"]) == 36 for r in summary_v025b["rows"]),
            "all_supplied_signed_numerator_upper_endpoints_negative": all(cutoffs_detail[n]["high_num"] < 0 for n in cutoffs_detail),
            "summary_rows_match_certificate_json": True,
            "endpoint_display_rounding_tolerance_decimal": "0.0001",
            "outward_rounding_proved": False,
            "max_certified_G_upper_decimal": max((Fraction(r["certified_G_upper_decimal"]) for r in summary_v025b["rows"])).__str__(),
            "min_normalizer_lower_bound_decimal": str(min(Fraction(r["normalizer_true_lower_bound_decimal"]) for r in summary_v025b["rows"])),
        },
        "n14_to_n15_supplied_record_reconciliation": {
            "nominal_signed_numerator_15_minus_14_decimal": dec_lower(nom_14_15, 6),
            "v028_P_signed_integral_lower_decimal": dec_lower(P_signed, 6),
            "nominal_minus_P_discrepancy_decimal": dec_upper(discrepancy_nom_vs_P, 6),
            "supplied_signed_numerator_15_minus_14_lower_decimal": transitions[0]["supplied_endpoint_increment_lower_decimal"],
            "supplied_signed_numerator_15_minus_14_upper_decimal": transitions[0]["supplied_endpoint_increment_upper_decimal"],
            "supplied_n14_n15_signed_numerator_intervals_separated": transitions[0]["intervals_strictly_separated"],
        },
        "cross_cutoff_transitions": transitions,
    }
    out_file = RESULTS_V029 / "module2_two_endpoint_bridge.json"
    out_file.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return result


# ============================================================================
# MODULE 3: Boundary-Annulus Telescoping + Two-Scale Dissipative Duhamel & e219
# ============================================================================
def validate_e219_modewise_certificate(cert: Dict[str, Any]) -> Dict[str, Any]:
    if cert.get("schema_id") != "wp19-v0.28-complex-fourier-error-vector-v1":
        raise ValueError("Invalid schema_id for e219 certificate")
    if int(cert.get("time_index", -1)) != 219:
        raise ValueError("time_index must be 219")
    entries = cert.get("modes", [])
    by_k = {tuple(e["k"]): e for e in entries}
    l2_sq_sum = Fraction(0)
    div_free_ok = True
    reality_ok = True
    for k, e in by_k.items():
        if k == (0, 0, 0):
            if any(Fraction(x) != 0 for x in e["center_real"]) or any(Fraction(x) != 0 for x in e["center_imag"]):
                raise ValueError("Zero mode must vanish under physical zero-mean projection")
            continue
        cr = [Fraction(x) for x in e["center_real"]]
        ci = [Fraction(x) for x in e["center_imag"]]
        rr = [Fraction(x) for x in e["radius_real"]]
        ri = [Fraction(x) for x in e["radius_imag"]]
        if any(r < 0 for r in rr + ri):
            raise ValueError(f"Negative radius at mode {k}")
        dot_re = abs(sum(k[i] * cr[i] for i in range(3)))
        dot_im = abs(sum(k[i] * ci[i] for i in range(3)))
        rad_re = sum(abs(k[i]) * rr[i] for i in range(3))
        rad_im = sum(abs(k[i]) * ri[i] for i in range(3))
        if dot_re > rad_re or dot_im > rad_im:
            div_free_ok = False
        neg_k = (-k[0], -k[1], -k[2])
        if neg_k not in by_k:
            reality_ok = False
        else:
            partner = by_k[neg_k]
            p_cr = [Fraction(x) for x in partner["center_real"]]
            p_ci = [-Fraction(x) for x in partner["center_imag"]]
            if p_cr != cr or p_ci != ci:
                reality_ok = False
        for i in range(3):
            u_re = abs(cr[i]) + rr[i]
            u_im = abs(ci[i]) + ri[i]
            l2_sq_sum += u_re * u_re + u_im * u_im

    return {
        "valid": div_free_ok and reality_ok,
        "divergence_free_enclosure_pass": div_free_ok,
        "conjugate_reality_symmetry_pass": reality_ok,
        "mode_count_validated": len(entries),
        "certified_L2_upper_decimal": dec_upper(sqrt_upper(l2_sq_sum, 30), 18),
    }


def run_module3_twoscale_dissipative_duhamel() -> Dict[str, Any]:
    harmonic_11 = sum(Fraction(1, j) for j in range(1, 12))  # 83711 / 27720
    asymptotic_tail_limit = harmonic_11 / 11  # 83711 / 304920

    direct_sum_18 = sum(Fraction(1, M * (M - 11)) for M in range(12, 19))
    tele_sum_18 = Fraction(1, 11) * sum(Fraction(1, j) - Fraction(1, 18 - 11 + j) for j in range(1, 12))
    if direct_sum_18 != tele_sum_18:
        raise AssertionError("Boundary-annulus telescoping identity failed at N=18")

    direct_sum_100 = sum(Fraction(1, M * (M - 11)) for M in range(12, 101))
    tele_sum_100 = Fraction(1, 11) * sum(Fraction(1, j) - Fraction(1, 100 - 11 + j) for j in range(1, 12))
    if direct_sum_100 != tele_sum_100:
        raise AssertionError("Boundary-annulus telescoping identity failed at N=100")

    seg_study = json.loads((DATA_V028 / "wp19_segments.json").read_text(encoding="utf-8"))
    n_seg = int(seg_study["n_segments"])
    T_horizon = Fraction(seg_study["horizon_T"])
    dt = T_horizon / n_seg
    defect_per_seg = Fraction(seg_study["per_segment_defect_bound"])
    rate_dissipative = float(seg_study["assumed_local_dissipative_rate"])
    rate_gronwall = float(seg_study["whole_path_gronwall_rate"])

    alpha_diss = math.exp(rate_dissipative * float(dt))
    alpha_gron = math.exp(rate_gronwall * float(dt))
    e_diss = 0.0
    e_gron = 0.0
    d_val = float(defect_per_seg)
    for _ in range(n_seg):
        e_diss = alpha_diss * e_diss + d_val
        e_gron = alpha_gron * e_gron + d_val

    nu = Fraction(1, 10)
    min_high_shell_k_sq = 12 * 12
    max_m15_k_sq = 15 * 15
    high_shell_damping_floor = nu * min_high_shell_k_sq
    high_shell_damping_ceiling = nu * max_m15_k_sq
    step_width_half = Fraction(1, 80000)
    high_shell_halfstep_decay = math.exp(-float(high_shell_damping_floor * step_width_half))

    sample_e219_cert = {
        "schema_id": "wp19-v0.28-complex-fourier-error-vector-v1",
        "time_index": 219,
        "modes": [
            {
                "k": [0, 0, 0],
                "center_real": ["0", "0", "0"],
                "center_imag": ["0", "0", "0"],
                "radius_real": ["0", "0", "0"],
                "radius_imag": ["0", "0", "0"],
            },
            {
                "k": [3, 2, 2],
                "center_real": ["0", "1/1000000", "-1/1000000"],
                "center_imag": ["0", "-1/2000000", "1/2000000"],
                "radius_real": ["1/10000000", "1/10000000", "1/10000000"],
                "radius_imag": ["1/10000000", "1/10000000", "1/10000000"],
            },
            {
                "k": [-3, -2, -2],
                "center_real": ["0", "1/1000000", "-1/1000000"],
                "center_imag": ["0", "1/2000000", "-1/2000000"],
                "radius_real": ["1/10000000", "1/10000000", "1/10000000"],
                "radius_imag": ["1/10000000", "1/10000000", "1/10000000"],
            },
        ],
    }
    e219_validation = validate_e219_modewise_certificate(sample_e219_cert)

    decomp = json.loads((DATA_V028 / "wp19_v0_28_structural_decomposition.json").read_text(encoding="utf-8"))
    shards = decomp["quadratic_20_step_shards"]
    total_quad = sum(Fraction(s["quadratic_upper_sum"]) for s in shards)
    tail_220_239_quad = Fraction(shards[-1]["quadratic_upper_sum"])
    tail_share = tail_220_239_quad / total_quad

    result = {
        "schema": "wp19-v0.29-twoscale-dissipative-duhamel-and-telescoping-v1",
        "status": "PASS_TELESCOPING_EXACT_AND_E219_VALIDATOR_READY",
        "claim_boundary": (
            "Proves exact rational telescoping of the WP19 v0.19 boundary-annulus direct-shell sum, "
            "quantifies the two-scale high-shell viscous damping floor (-nu |k|^2 <= -14.4 for |k|>=12), "
            "verifies the piecewise Duhamel vs. single-rate Gronwall reduction on wp19_segments.json, "
            "and provides an executable validator for wp19-v0.28-complex-fourier-error-vector-v1."
        ),
        "boundary_annulus_telescoping": {
            "harmonic_11_exact": str(harmonic_11),
            "asymptotic_sum_limit_M12_to_inf_exact": str(asymptotic_tail_limit),
            "asymptotic_sum_limit_decimal": dec_upper(asymptotic_tail_limit, 18),
            "partial_sum_M12_to_18_exact": str(direct_sum_18),
            "partial_sum_M12_to_100_exact": str(direct_sum_100),
            "exact_telescoping_identity_verified": True,
        },
        "twoscale_high_shell_dissipation": {
            "viscosity_nu_exact": "1/10",
            "outer_shell_k_sq_range_M15": [min_high_shell_k_sq, max_m15_k_sq],
            "linear_damping_rate_range_per_unit_time": [str(high_shell_damping_floor), str(high_shell_damping_ceiling)],
            "half_step_viscous_contraction_factor_at_k12": f"{high_shell_halfstep_decay:.12f}",
            "strength_fourier_young_a2_constant": "0.184920",
            "tail_220_239_fraction_of_whole_path_quadratic": dec_upper(tail_share, 8),
        },
        "piecewise_duhamel_study_verification": {
            "n_segments": n_seg,
            "dissipative_terminal_error": f"{e_diss:.12e}",
            "single_rate_gronwall_terminal_error": f"{e_gron:.12e}",
            "suppression_ratio_gronwall_over_dissipative": f"{e_gron / e_diss:.6e}",
            "strictly_contractive_vs_gronwall": e_diss < e_gron,
        },
        "e219_modewise_validator_self_test": e219_validation,
    }
    out_file = RESULTS_V029 / "module3_twoscale_dissipative_duhamel.json"
    out_file.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return result


# ============================================================================
# MODULE 4: Reverse-Time Adjoint Sign Reconciliation & Structured A/B Audit
# ============================================================================
def outward_exp_upper(x: decimal.Decimal, ctx: decimal.Context) -> decimal.Decimal:
    return ctx.next_plus(ctx.exp(x))


def outward_step_recurrence(
    e_in: decimal.Decimal,
    L_rate: decimal.Decimal,
    R_res: decimal.Decimal,
    h_step: decimal.Decimal,
    ctx: decimal.Context,
) -> decimal.Decimal:
    lh = ctx.multiply(L_rate, h_step)
    exp_lh = outward_exp_upper(lh, ctx)
    term1 = ctx.multiply(exp_lh, e_in)
    num = ctx.subtract(exp_lh, decimal.Decimal(1))
    factor = ctx.divide(num, L_rate)
    term2 = ctx.multiply(factor, R_res)
    return ctx.add(term1, term2)


def run_module4_reverse_time_reconciliation() -> Dict[str, Any]:
    corr_chain = json.loads((DATA_V028 / "corrected_recurrence_chain.json").read_text(encoding="utf-8"))
    struct_ab = json.loads((DATA_V028 / "structured_uncertainty_ab.json").read_text(encoding="utf-8"))

    ctx = decimal.Context(prec=90, rounding=decimal.ROUND_CEILING)
    h_step = decimal.Decimal("0.0000125")
    nu_kmax_sq = decimal.Decimal("22.5")

    e_conservative = decimal.Decimal(corr_chain["segments"][0]["incoming_error_upper_corrected_chain"])
    e_dissipative_strain_only = e_conservative

    replayed_segments = []
    for seg in corr_chain["segments"]:
        step_idx = int(seg["step"])
        L_strain = decimal.Decimal(seg["strain_log_norm_upper_imported"])
        L_total = ctx.add(L_strain, nu_kmax_sq)
        R_res = decimal.Decimal(seg["residual_L2_upper_imported"])

        e_cons_out = outward_step_recurrence(e_conservative, L_total, R_res, h_step, ctx)
        e_diss_out = outward_step_recurrence(e_dissipative_strain_only, L_strain, R_res, h_step, ctx)

        published_cons_out = decimal.Decimal(seg["outgoing_error_upper_corrected_chain"])
        if str(e_cons_out) != str(published_cons_out):
            raise AssertionError(f"Step {step_idx} conservative replay mismatch: {e_cons_out} != {published_cons_out}")

        replayed_segments.append({
            "step": step_idx,
            "interval_rational": seg["forward_time_interval_rational"],
            "L_strain_upper": str(L_strain),
            "L_plus_22_5_upper": str(L_total),
            "residual_L2_upper": str(R_res),
            "outgoing_L_plus_22_5_verified": str(e_cons_out),
            "outgoing_dissipative_strain_only": str(e_diss_out),
            "dissipative_tightening_saving": str(ctx.subtract(e_cons_out, e_diss_out)),
        })
        e_conservative = e_cons_out
        e_dissipative_strain_only = e_diss_out

    penalty_ratio = Fraction(struct_ab["new_over_old_penalty_upper"])
    threshold = Fraction(struct_ab["predeclared_materiality_threshold_new_over_old"])

    result = {
        "schema": "wp19-v0.29-reverse-time-and-structured-ab-reconciliation-v1",
        "status": "PASS_90_DIGIT_EXACT_REPLAY_AND_MATERIAL_TIGHTENING",
        "claim_boundary": (
            "Independently replays and reconciles the 90-digit outward-rounded M14 3-segment backward "
            "recurrence (steps 239->238->237) under both the conservative L+22.5 bound and the reverse-time "
            "viscous-dissipative strain-only bound, plus the step-237 structured Fourier-Young VJP tightening."
        ),
        "three_segment_chain_replay": replayed_segments,
        "step_237_structured_fourier_young_ab": {
            "old_componentwise_triangle_penalty_upper": struct_ab["old_componentwise_triangle_penalty_upper"],
            "structured_fourier_young_penalty_upper": struct_ab["structured_fourier_young_penalty_upper"],
            "new_over_old_penalty_ratio": struct_ab["new_over_old_penalty_upper"],
            "materiality_threshold": struct_ab["predeclared_materiality_threshold_new_over_old"],
            "passes_materiality_gate": penalty_ratio < threshold,
            "direct_vjp_convolution_self_check": struct_ab["independent_direct_convolution_self_check"]["status"],
        },
    }
    out_file = RESULTS_V029 / "module4_reverse_time_reconciliation.json"
    out_file.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return result


# ============================================================================
# MODULE 5: Unauthenticated Artifact Integrity Manifest
# ============================================================================
def run_module5_artifact_integrity_manifest(
    m1: Dict[str, Any],
    m2: Dict[str, Any],
    m3: Dict[str, Any],
    m4: Dict[str, Any],
    lean_audit: Dict[str, Any],
) -> Dict[str, Any]:
    if not (
        m1["certified_n15_endpoint_ball_taylor_closure"]["RG_local_strictly_below_old_Q_plus_B"]
        and m1["certified_n15_endpoint_ball_taylor_closure"]["pairwise_perturbation_strictly_below_P"]
        and m1["outward_rounding_audit"]["pass"]
        and m2["n11_to_n18_supplied_record_checks"]["all_supplied_signed_numerator_upper_endpoints_negative"]
        and m2["n14_to_n15_supplied_record_reconciliation"]["supplied_n14_n15_signed_numerator_intervals_separated"]
        and m3["boundary_annulus_telescoping"]["exact_telescoping_identity_verified"]
        and m3["e219_modewise_validator_self_test"]["valid"]
        and m4["step_237_structured_fourier_young_ab"]["passes_materiality_gate"]
        and lean_audit["status"] == "SOURCE_SCAN_ONLY_NO_LEAN_COMPILER"
    ):
        raise RuntimeError("Finite arithmetic replay or source scan failed.")

    artifact_hashes = {}
    for rel in [
        "results/wp19_v0_29/module1_localized_active_hessian.json",
        "results/wp19_v0_29/module2_two_endpoint_bridge.json",
        "results/wp19_v0_29/module3_twoscale_dissipative_duhamel.json",
        "results/wp19_v0_29/module4_reverse_time_reconciliation.json",
        "lean/NavierStokesWP19BridgeCert.lean",
        "tools/check_ns_lean_axioms.py",
        "src/navier_stokes_v029_closure_suite.py",
    ]:
        artifact_hashes[rel] = sha256_file(REPO_ROOT / rel)

    manifest = {
        "schema": "wp19-v0.29.1-artifact-integrity-manifest-v1",
        "release_version": "wp19-v0.29.1-audit-correction",
        "status": "CHECKSUMS_RECORDED_NOT_AUTHENTICATED",
        "authenticity": "NONE",
        "hash_algorithm": "SHA-256",
        "scope_note": "Unkeyed checksums detect accidental changes only when compared with a trusted copy; they do not authenticate authorship or prevent archive replacement.",
        "artifact_hashes": artifact_hashes,
        "upstream_provenance": "The original Arb raw inputs and trajectories are not included; the supplied N=11..18 certificate JSON arithmetic is replayed but the upstream Arb calculations are not reproduced.",
        "verification_boundary": {
            "lean_source_scan": lean_audit["status"],
            "lean_compiler": "NOT_RUN_BY_PYTHON_SUITE",
            "continuum_regularity": "OPEN",
        },
    }
    out_file = RESULTS_V029 / "artifact_integrity_manifest.json"
    out_file.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return manifest


def run_all() -> Dict[str, Any]:
    RESULTS_V029.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(REPO_ROOT / "tools"))
    import check_ns_lean_axioms  # type: ignore

    lean_audit = check_ns_lean_axioms.audit_lean_source()
    m1 = run_module1_localized_active_hessian()
    m2 = run_module2_two_endpoint_bridge()
    m3 = run_module3_twoscale_dissipative_duhamel()
    m4 = run_module4_reverse_time_reconciliation()
    m5 = run_module5_artifact_integrity_manifest(m1, m2, m3, m4, lean_audit)

    summary = {
        "suite": "navier-stokes-bridge-audit-v0.29.1-audit-correction",
        "status": "PASS_FINITE_ARITHMETIC_REPLAY_AND_SOURCE_SCAN_ONLY",
        "verification_boundary": {
            "lean_source_scan": lean_audit["status"],
            "lean_compiler": "NOT_RUN_BY_PYTHON_SUITE",
            "continuum_regularity": "OPEN",
            "artifact_authenticity": "NONE_UNKEYED_CHECKSUMS_ONLY",
        },
        "highlights": {
            "active_modes_in_G": m1["active_support_topology"]["active_objective_modes_S_obj"],
            "kernel_modes_annihilated_in_B15": m1["active_support_topology"]["kernel_modes_in_B15"],
            "hessian_algebraic_reduction_factor": m1["hessian_operator_constants"]["total_algebraic_reduction_factor_exact"],
            "RG_local_over_old_Q_plus_B_at_N15": m1["certified_n15_endpoint_ball_taylor_closure"]["RG_local_over_old_Q_plus_B_decimal"],
            "pairwise_perturbation_over_P_at_N15": m1["certified_n15_endpoint_ball_taylor_closure"]["pairwise_perturbation_over_P_decimal"],
            "RG_improvement_over_v028_coarse": m1["certified_n15_endpoint_ball_taylor_closure"]["improvement_factor_over_v028_coarse_decimal"],
            "supplied_signed_numerator_15_minus_14_interval": [
                m2["n14_to_n15_supplied_record_reconciliation"]["supplied_signed_numerator_15_minus_14_lower_decimal"],
                m2["n14_to_n15_supplied_record_reconciliation"]["supplied_signed_numerator_15_minus_14_upper_decimal"],
            ],
            "repaired_v028_negative_margin_floor": m1["outward_rounding_audit"]["repaired_v029_outward_floor_24_places"],
            "lean_theorem_declaration_count_source_scan_only": lean_audit["theorem_declaration_count"],
            "artifact_authenticity": m5["authenticity"],
        },
    }
    (RESULTS_V029 / "WP19_v0_29_MASTER_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, sort_keys=True))
    return summary


if __name__ == "__main__":
    run_all()
